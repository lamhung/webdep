<div class="page-title">
   <div class="row">
        <div class="col-md-12">
            <h4><span class="glyphicon glyphicon-log-in">&nbsp;</span><?php echo $this->lang->line('user_add')?></h4>
        </div>
    </div>  
</div>
<?php $this->load->view('backend/user/_form');?>
        
