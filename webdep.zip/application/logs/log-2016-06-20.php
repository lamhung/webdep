<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 20-06-2016 09:25:31 --> 404 Page Not Found: Faviconico/index
ERROR - 20-06-2016 09:33:58 --> 404 Page Not Found: Acp/user
ERROR - 20-06-2016 10:12:28 --> 404 Page Not Found: Faviconico/index
ERROR - 20-06-2016 10:13:06 --> 404 Page Not Found: Acp/user
ERROR - 20-06-2016 10:13:09 --> 404 Page Not Found: Acp/user
ERROR - 20-06-2016 10:14:24 --> Severity: Notice --> Undefined index: group D:\Projects\webdep\application\views\backend\user\_form.php 36
ERROR - 20-06-2016 10:14:24 --> Severity: Notice --> Undefined index: group D:\Projects\webdep\application\views\backend\user\_form.php 39
ERROR - 20-06-2016 10:14:24 --> Severity: Notice --> Undefined index: image_ D:\Projects\webdep\application\views\backend\user\_form.php 57
ERROR - 20-06-2016 10:15:20 --> Severity: Notice --> Undefined index: image_ D:\Projects\webdep\application\views\backend\user\_form.php 57
ERROR - 20-06-2016 10:15:35 --> Severity: Notice --> Undefined index: image_ D:\Projects\webdep\application\views\backend\user\_form.php 57
ERROR - 20-06-2016 10:29:38 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 92
ERROR - 20-06-2016 10:35:26 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 92
ERROR - 20-06-2016 10:35:46 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 92
ERROR - 20-06-2016 10:58:09 --> 404 Page Not Found: backend/User/index
ERROR - 20-06-2016 10:58:29 --> 404 Page Not Found: backend/User/index
ERROR - 20-06-2016 11:02:59 --> 404 Page Not Found: backend/User/index
ERROR - 20-06-2016 11:05:38 --> 404 Page Not Found: backend/User/index
ERROR - 20-06-2016 11:05:43 --> 404 Page Not Found: Acp/add
