<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 21-06-2016 06:16:28 --> 404 Page Not Found: Faviconico/index
ERROR - 21-06-2016 06:17:11 --> Severity: Notice --> Undefined property: User::$pagination_mylib D:\Projects\webdep\application\controllers\backend\User.php 14
ERROR - 21-06-2016 06:17:11 --> Severity: Error --> Call to a member function bootstrap_configs() on null D:\Projects\webdep\application\controllers\backend\User.php 14
ERROR - 21-06-2016 06:34:03 --> Could not find the language line "user_groups"
ERROR - 21-06-2016 06:34:03 --> Could not find the language line "user_statsus"
ERROR - 21-06-2016 06:34:24 --> Could not find the language line "user_groups"
ERROR - 21-06-2016 06:34:24 --> Could not find the language line "user_statsus"
ERROR - 21-06-2016 06:34:37 --> Could not find the language line "user_groups"
ERROR - 21-06-2016 06:39:19 --> Could not find the language line "user_groups"
ERROR - 21-06-2016 06:45:21 --> Could not find the language line "user_groups"
ERROR - 21-06-2016 06:47:04 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:49:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:50:24 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:50:44 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:50:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:51:37 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:53:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:54:09 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:54:19 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:58:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:59:42 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:59:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 06:59:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 09:47:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE 
ERROR - 21-06-2016 09:48:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE 
ERROR - 21-06-2016 09:49:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 09:49:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 09:49:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 09:49:50 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT COUNT(id) FROM th_users WHERE  type = 'web' AND deleted = 0
ERROR - 21-06-2016 09:50:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE   
ERROR - 21-06-2016 09:50:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE (`username` LIKE '%l%' ESCAPE '!' OR  `fullname` LIKE '%l%' ESCAPE '!') AND   
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:51:10 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:51:10 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:51:10 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:51:10 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:51:10 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:51:10 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:51:10 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:51:24 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:51:24 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:51:24 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:51:24 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:51:24 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:51:24 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:51:24 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:51:25 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:51:25 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:51:25 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:51:25 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:51:30 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:51:30 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:51:30 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:51:30 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:51:30 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:51:30 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:51:30 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:52:22 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:52:22 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:52:22 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:52:22 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:52:22 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:52:22 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:52:22 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:53:17 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:53:17 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:53:17 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:53:17 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:53:17 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:53:17 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:53:17 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:55:07 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:55:07 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:55:07 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: gender D:\Projects\webdep\application\models\User_model.php 31
ERROR - 21-06-2016 09:55:07 --> Could not find the language line "user_gender_"
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: status D:\Projects\webdep\application\models\User_model.php 32
ERROR - 21-06-2016 09:55:07 --> Could not find the language line "user_status_"
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: groups D:\Projects\webdep\application\models\User_model.php 33
ERROR - 21-06-2016 09:55:07 --> Could not find the language line "user_group_"
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: fullname D:\Projects\webdep\application\views\backend\user\index.php 37
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: username D:\Projects\webdep\application\views\backend\user\index.php 38
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: phone D:\Projects\webdep\application\views\backend\user\index.php 40
ERROR - 21-06-2016 09:55:07 --> Severity: Notice --> Undefined index: email D:\Projects\webdep\application\views\backend\user\index.php 41
ERROR - 21-06-2016 10:32:36 --> Severity: Notice --> Undefined variable: capcha_image D:\Projects\webdep\application\views\backend\auth\login.php 93
ERROR - 21-06-2016 10:32:36 --> Severity: Notice --> Undefined variable: msg D:\Projects\webdep\application\views\backend\auth\login.php 95
ERROR - 21-06-2016 10:32:36 --> 404 Page Not Found: Assets/frontend
ERROR - 21-06-2016 10:32:36 --> 404 Page Not Found: Assets/frontend
ERROR - 21-06-2016 10:34:02 --> Severity: Notice --> Undefined variable: capcha_image D:\Projects\webdep\application\views\backend\auth\login.php 93
ERROR - 21-06-2016 10:34:02 --> Severity: Notice --> Undefined variable: msg D:\Projects\webdep\application\views\backend\auth\login.php 95
ERROR - 21-06-2016 10:34:02 --> 404 Page Not Found: Assets/frontend
ERROR - 21-06-2016 10:34:25 --> Severity: Notice --> Undefined variable: capcha_image D:\Projects\webdep\application\views\backend\auth\login.php 93
ERROR - 21-06-2016 10:34:25 --> Severity: Notice --> Undefined variable: msg D:\Projects\webdep\application\views\backend\auth\login.php 95
ERROR - 21-06-2016 10:39:28 --> Severity: Notice --> Undefined variable: capcha_image D:\Projects\webdep\application\views\backend\auth\login.php 93
ERROR - 21-06-2016 10:39:28 --> Severity: Notice --> Undefined variable: msg D:\Projects\webdep\application\views\backend\auth\login.php 95
ERROR - 21-06-2016 10:40:36 --> Severity: Notice --> Undefined variable: capcha_image D:\Projects\webdep\application\views\backend\auth\login.php 93
ERROR - 21-06-2016 10:40:36 --> Severity: Notice --> Undefined variable: msg D:\Projects\webdep\application\views\backend\auth\login.php 95
ERROR - 21-06-2016 11:19:21 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:19:21 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:19:21 --> Severity: Notice --> Undefined index: password D:\Projects\webdep\application\models\User_model.php 64
ERROR - 21-06-2016 11:19:21 --> Could not find the language line "auth_password_not_available"
ERROR - 21-06-2016 11:19:52 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:19:52 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:19:52 --> Severity: Notice --> Undefined index: group D:\Projects\webdep\application\models\User_model.php 74
ERROR - 21-06-2016 11:24:30 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:24:30 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:24:34 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:24:34 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:24:37 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:24:37 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:24:43 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:24:43 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:25:08 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:25:08 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:25:12 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:25:12 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:25:12 --> Could not find the language line "auth_password_not_available"
ERROR - 21-06-2016 11:25:18 --> Could not find the language line "auth_user"
ERROR - 21-06-2016 11:25:18 --> Could not find the language line "auth_pass"
ERROR - 21-06-2016 11:25:18 --> Could not find the language line "auth_password_not_available"
ERROR - 21-06-2016 12:08:34 --> Severity: Notice --> Undefined variable: current_uri D:\Projects\webdep\application\controllers\backend\Auth.php 74
ERROR - 21-06-2016 12:09:12 --> Severity: Notice --> Undefined variable: current_uri D:\Projects\webdep\application\controllers\backend\Auth.php 74
ERROR - 21-06-2016 12:09:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE   
ERROR - 21-06-2016 12:14:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE   
ERROR - 21-06-2016 12:14:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE   
ERROR - 21-06-2016 12:15:22 --> Severity: Notice --> Undefined variable: post D:\Projects\webdep\application\controllers\backend\User.php 42
ERROR - 21-06-2016 12:15:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:15:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:16:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:16:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:19:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:19:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:19:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:20:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:20:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT 25 OFFSET 0' at line 1 - Invalid query: SELECT * FROM th_users WHERE  LIMIT 25 OFFSET 0
ERROR - 21-06-2016 12:24:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:25:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:25:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:25:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:26:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:26:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:28:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:28:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:28:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(id) FROM th_users WHERE  
ERROR - 21-06-2016 12:30:14 --> Severity: Error --> Unsupported operand types D:\Projects\webdep\system\libraries\Pagination.php 409
ERROR - 21-06-2016 17:24:24 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 17:25:58 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 17:36:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 17:36:44 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 17:37:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 21-06-2016 17:38:19 --> 404 Page Not Found: Vendor/bootstrap
