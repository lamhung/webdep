<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 23-06-2016 09:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:03:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:31 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:32 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:32 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:33 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:34 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:35 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:36 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:36 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:37 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:37 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:37 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:37 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:38 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:38 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:39 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:39 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:39 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:40 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:40 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:40 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:40 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:40 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:40 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:41 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:41 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:41 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:41 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:42 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:42 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:42 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:43 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:43 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:43 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:43 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:44 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:44 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:44 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:45 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:45 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:45 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:45 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:45 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:45 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:46 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:46 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:47 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:47 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:47 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:47 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:47 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:47 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:48 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:48 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:48 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:48 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:49 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:50 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:50 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:50 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:50 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:50 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:50 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:51 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:51 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:52 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:52 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:53 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:53 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:54 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:54 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:54 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:55 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:56 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:56 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:56 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:56 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:57 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:58 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:58 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:59 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:59 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:59 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:59 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:08:59 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:08:59 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:00 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:00 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:01 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:02 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:02 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:02 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:03 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:03 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:09:04 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 23-06-2016 09:09:04 --> Severity: Notice --> Undefined variable: records D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 23-06-2016 09:09:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:12 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:13 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:13 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:14 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:14 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:21 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:21 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:22 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:22 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:24 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:24 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:25 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:25 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:30 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:31 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:36 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:13:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:11 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:11 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:12 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:12 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:13 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:13 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:23 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:23 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:25 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:25 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:27 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:27 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:28 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:28 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:32 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:32 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:36 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:15:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:02 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:02 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:03 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:04 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:12 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:12 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:15 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:15 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:19 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:19 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:20 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:20 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:23 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:16:23 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 23-06-2016 09:26:27 --> 404 Page Not Found: Faviconico/index
ERROR - 23-06-2016 09:31:17 --> Severity: Error --> Cannot use object of type simple_html_dom_node as array D:\Projects\webdep\application\controllers\backend\Get_news.php 20
ERROR - 23-06-2016 09:36:09 --> Severity: Error --> Cannot use object of type simple_html_dom_node as array D:\Projects\webdep\application\controllers\backend\Get_news.php 20
ERROR - 23-06-2016 09:36:25 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:26 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:26 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:27 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:27 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:28 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:28 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:30 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:33 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:34 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:34 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:39 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:40 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:36:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 21
ERROR - 23-06-2016 09:37:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:02 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:06 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:06 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:06 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:06 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:07 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:07 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:08 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:09 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:09 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:09 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:09 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:10 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:10 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:11 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:11 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:11 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:13 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:14 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:37:15 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 22
ERROR - 23-06-2016 09:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 23-06-2016 09:55:40 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 68
ERROR - 23-06-2016 09:55:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 68
ERROR - 23-06-2016 09:55:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 68
ERROR - 23-06-2016 09:55:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 68
ERROR - 23-06-2016 09:55:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 68
ERROR - 23-06-2016 09:55:42 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 68
ERROR - 23-06-2016 10:47:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\controllers\backend\Get_news.php 23
ERROR - 23-06-2016 10:50:45 --> Severity: Notice --> Undefined variable: record D:\Projects\webdep\application\controllers\backend\Get_news.php 27
ERROR - 23-06-2016 10:50:45 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 27
ERROR - 23-06-2016 11:26:06 --> Severity: Error --> Call to undefined function directory_exist() D:\Projects\webdep\application\controllers\backend\Get_news.php 54
ERROR - 23-06-2016 11:28:27 --> Severity: Warning --> file_put_contents(new/get_new/2016/06/canhsatbien2-1466658634_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:28:28 --> Severity: Warning --> file_put_contents(new/get_new/2016/06/a-1466648478_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:28:29 --> Severity: Warning --> file_put_contents(new/get_new/2016/06/maybay1-1466653725_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:28:29 --> Severity: Warning --> file_put_contents(new/get_new/2016/06/chodongdang-1466668481_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:28:29 --> Severity: Warning --> file_put_contents(new/get_new/2016/06/hitgirl-1466669652_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:28:30 --> Severity: Warning --> file_put_contents(new/get_new/2016/06/top-1466669229_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:08 --> Severity: Warning --> file_put_contents(new/2016/06/canhsatbien2-1466658634_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:08 --> Severity: Warning --> file_put_contents(new/2016/06/a-1466648478_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:09 --> Severity: Warning --> file_put_contents(new/2016/06/maybay1-1466653725_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:10 --> Severity: Warning --> file_put_contents(new/2016/06/chodongdang-1466668481_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:10 --> Severity: Warning --> file_put_contents(new/2016/06/hitgirl-1466669652_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:11 --> Severity: Warning --> file_put_contents(new/2016/06/top-1466669229_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:11 --> Severity: Warning --> file_put_contents(new/2016/06/bt2-3863-1466662353_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:12 --> Severity: Warning --> file_put_contents(new/2016/06/tauca-1466656160_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:13 --> Severity: Warning --> file_put_contents(new/2016/06/1350884012325495234231049143929231724268244n-1466656560_1466656586_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:14 --> Severity: Warning --> file_put_contents(new/2016/06/IMG5858JPG-1466652448_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:15 --> Severity: Warning --> file_put_contents(new/2016/06/top-1466637340_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:34:15 --> Severity: Warning --> file_put_contents(new/2016/06/hanquoc-6716-1466662711_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:14 --> Severity: Warning --> file_put_contents(new/2016/06/canhsatbien2-1466658634_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:14 --> Severity: Warning --> file_put_contents(new/2016/06/a-1466648478_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:14 --> Severity: Warning --> file_put_contents(new/2016/06/maybay1-1466653725_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:14 --> Severity: Warning --> file_put_contents(new/2016/06/chodongdang-1466668481_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:15 --> Severity: Warning --> file_put_contents(new/2016/06/hitgirl-1466669652_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:15 --> Severity: Warning --> file_put_contents(new/2016/06/top-1466669229_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:16 --> Severity: Warning --> file_put_contents(new/2016/06/bt2-3863-1466662353_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:16 --> Severity: Warning --> file_put_contents(new/2016/06/tauca-1466656160_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:16 --> Severity: Warning --> file_put_contents(new/2016/06/1350884012325495234231049143929231724268244n-1466656560_1466656586_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:16 --> Severity: Warning --> file_put_contents(new/2016/06/IMG5858JPG-1466652448_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:17 --> Severity: Warning --> file_put_contents(new/2016/06/top-1466637340_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:17 --> Severity: Warning --> file_put_contents(new/2016/06/hanquoc-6716-1466662711_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:18 --> Severity: Warning --> file_put_contents(new/2016/06/chile-9962-1466655822_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:18 --> Severity: Warning --> file_put_contents(new/2016/06/ST20160620XSTEM2379896-1466583545_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:19 --> Severity: Warning --> file_put_contents(new/2016/06/xang061081424777587-1466663023_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:19 --> Severity: Warning --> file_put_contents(new/2016/06/0023ae82cb0c1440691020-1466668317_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:20 --> Severity: Warning --> file_put_contents(new/2016/06/daigiaLuanok-1466655222_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:35:21 --> Severity: Warning --> file_put_contents(new/2016/06/nguoidanchanxe69591466588359-1466666614_1466666624_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 86
ERROR - 23-06-2016 11:37:50 --> Severity: Warning --> file_put_contents(new/2016/06/canhsatbien2-1466658634_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:50 --> Severity: Warning --> file_put_contents(new/2016/06/a-1466648478_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:51 --> Severity: Warning --> file_put_contents(new/2016/06/maybay1-1466653725_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:51 --> Severity: Warning --> file_put_contents(new/2016/06/chodongdang-1466668481_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:51 --> Severity: Warning --> file_put_contents(new/2016/06/hitgirl-1466669652_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:52 --> Severity: Warning --> file_put_contents(new/2016/06/top-1466669229_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:53 --> Severity: Warning --> file_put_contents(new/2016/06/bt2-3863-1466662353_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:54 --> Severity: Warning --> file_put_contents(new/2016/06/tauca-1466656160_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:54 --> Severity: Warning --> file_put_contents(new/2016/06/1350884012325495234231049143929231724268244n-1466656560_1466656586_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:55 --> Severity: Warning --> file_put_contents(new/2016/06/IMG5858JPG-1466652448_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:55 --> Severity: Warning --> file_put_contents(new/2016/06/top-1466637340_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:55 --> Severity: Warning --> file_put_contents(new/2016/06/hanquoc-6716-1466662711_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:56 --> Severity: Warning --> file_put_contents(new/2016/06/chile-9962-1466655822_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:56 --> Severity: Warning --> file_put_contents(new/2016/06/ST20160620XSTEM2379896-1466583545_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:57 --> Severity: Warning --> file_put_contents(new/2016/06/xang061081424777587-1466663023_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:57 --> Severity: Warning --> file_put_contents(new/2016/06/0023ae82cb0c1440691020-1466668317_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:58 --> Severity: Warning --> file_put_contents(new/2016/06/daigiaLuanok-1466655222_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:59 --> Severity: Warning --> file_put_contents(new/2016/06/nguoidanchanxe69591466588359-1466666614_1466666624_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:37:59 --> Severity: Warning --> file_put_contents(new/2016/06/a-1466674077_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:38:00 --> Severity: Warning --> file_put_contents(new/2016/06/ck-1466672866_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:38:00 --> Severity: Warning --> file_put_contents(new/2016/06/xemtuongron-1466589038_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:38:00 --> Severity: Warning --> file_put_contents(new/2016/06/my-nhan-co-dau-8-tuoi-rang-ro-khi-tro-lai-viet-nam-1466668526_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:38:00 --> Severity: Warning --> file_put_contents(new/2016/06/2-1466653424_180x108.png): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:38:01 --> Severity: Warning --> file_put_contents(new/2016/06/looking-2011-1466668604_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:16 --> Severity: Warning --> file_put_contents(new/canhsatbien2-1466658634_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:16 --> Severity: Warning --> file_put_contents(new/a-1466648478_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:17 --> Severity: Warning --> file_put_contents(new/maybay1-1466653725_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:17 --> Severity: Warning --> file_put_contents(new/chodongdang-1466668481_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:18 --> Severity: Warning --> file_put_contents(new/hitgirl-1466669652_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:19 --> Severity: Warning --> file_put_contents(new/top-1466669229_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:19 --> Severity: Warning --> file_put_contents(new/bt2-3863-1466662353_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:20 --> Severity: Warning --> file_put_contents(new/tauca-1466656160_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:20 --> Severity: Warning --> file_put_contents(new/1350884012325495234231049143929231724268244n-1466656560_1466656586_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:21 --> Severity: Warning --> file_put_contents(new/IMG5858JPG-1466652448_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:21 --> Severity: Warning --> file_put_contents(new/top-1466637340_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:21 --> Severity: Warning --> file_put_contents(new/hanquoc-6716-1466662711_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:22 --> Severity: Warning --> file_put_contents(new/chile-9962-1466655822_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:22 --> Severity: Warning --> file_put_contents(new/ST20160620XSTEM2379896-1466583545_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:23 --> Severity: Warning --> file_put_contents(new/xang061081424777587-1466663023_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:23 --> Severity: Warning --> file_put_contents(new/0023ae82cb0c1440691020-1466668317_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:24 --> Severity: Warning --> file_put_contents(new/daigiaLuanok-1466655222_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:25 --> Severity: Warning --> file_put_contents(new/nguoidanchanxe69591466588359-1466666614_1466666624_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:25 --> Severity: Warning --> file_put_contents(new/a-1466674077_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:26 --> Severity: Warning --> file_put_contents(new/ck-1466672866_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:26 --> Severity: Warning --> file_put_contents(new/xemtuongron-1466589038_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:26 --> Severity: Warning --> file_put_contents(new/my-nhan-co-dau-8-tuoi-rang-ro-khi-tro-lai-viet-nam-1466668526_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:26 --> Severity: Warning --> file_put_contents(new/2-1466653424_180x108.png): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:27 --> Severity: Warning --> file_put_contents(new/looking-2011-1466668604_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:27 --> Severity: Warning --> file_put_contents(new/phone-9-2730-1466665192_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:28 --> Severity: Warning --> file_put_contents(new/biencamretrai-cafeautovn-3-146-2607-5833-1466608307_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:29 --> Severity: Warning --> file_put_contents(new/Nga-Nhi-2-JPG-9071-1466652657_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:30 --> Severity: Warning --> file_put_contents(new/VNETombJPG29781466503728-1466671764_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:31 --> Severity: Warning --> file_put_contents(new/cgaibuon-1466657208_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:40:31 --> Severity: Warning --> file_put_contents(new/1-1466651702_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 87
ERROR - 23-06-2016 11:51:15 --> Severity: Warning --> file_put_contents(/new/a-1466674077_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 88
ERROR - 23-06-2016 11:51:16 --> Severity: Warning --> file_put_contents(/new/canhsatbien2-1466658634_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 88
ERROR - 23-06-2016 11:51:16 --> Severity: Warning --> file_put_contents(/new/a-1466648478_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 88
ERROR - 23-06-2016 11:51:17 --> Severity: Warning --> file_put_contents(/new/maybay1-1466653725_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 88
ERROR - 23-06-2016 11:51:17 --> Severity: Warning --> file_put_contents(/new/chodongdang-1466668481_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 88
ERROR - 23-06-2016 11:51:18 --> Severity: Warning --> file_put_contents(/new/hitgirl-1466669652_180x108.jpg): failed to open stream: No such file or directory D:\Projects\webdep\application\controllers\backend\Get_news.php 88
