<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 17-06-2016 04:34:03 --> 404 Page Not Found: Faviconico/index
ERROR - 17-06-2016 05:37:16 --> Severity: Notice --> Undefined variable: path D:\Projects\webdep\application\controllers\backend\User.php 13
ERROR - 17-06-2016 07:02:34 --> Severity: Error --> Call to undefined function directory_exist() D:\Projects\webdep\application\libraries\Image_mylib.php 33
ERROR - 17-06-2016 07:09:27 --> Severity: Error --> Call to undefined function directory_exist() D:\Projects\webdep\application\libraries\Image_mylib.php 34
ERROR - 17-06-2016 07:19:08 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 29
ERROR - 17-06-2016 07:19:08 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 09:06:02 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 29
ERROR - 17-06-2016 09:06:02 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 09:07:36 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 09:07:54 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 29
ERROR - 17-06-2016 09:07:54 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 09:12:53 --> Severity: Notice --> Undefined index: filename D:\Projects\webdep\application\libraries\Image_mylib.php 73
ERROR - 17-06-2016 09:12:53 --> Severity: Warning --> imagejpeg(D:\Projects\webdep\uploads/user/thumbnail/): failed to open stream: No such file or directory D:\Projects\webdep\application\libraries\Image_mylib.php 121
ERROR - 17-06-2016 09:12:53 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 29
ERROR - 17-06-2016 09:12:54 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 10:08:51 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 29
ERROR - 17-06-2016 10:08:51 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 10:11:24 --> Severity: Notice --> Undefined index: error D:\Projects\webdep\application\controllers\backend\User.php 29
ERROR - 17-06-2016 10:11:24 --> 404 Page Not Found: Acp/user
ERROR - 17-06-2016 11:29:46 --> Could not find the language line "user_groups"
ERROR - 17-06-2016 11:35:38 --> Could not find the language line "user_birhtday"
ERROR - 17-06-2016 11:36:36 --> Could not find the language line "user_create_at"
ERROR - 17-06-2016 11:36:36 --> Severity: Notice --> Undefined index: create_at_ D:\Projects\webdep\application\views\backend\user\show.php 53
ERROR - 17-06-2016 11:37:12 --> Severity: Notice --> Undefined index: created_at_ D:\Projects\webdep\application\views\backend\user\show.php 53
ERROR - 17-06-2016 11:37:58 --> Could not find the language line "user_created_at"
ERROR - 17-06-2016 11:37:58 --> Severity: Notice --> Undefined index: created_at_ D:\Projects\webdep\application\views\backend\user\show.php 53
ERROR - 17-06-2016 11:38:11 --> Severity: Notice --> Undefined index: create_at_ D:\Projects\webdep\application\views\backend\user\show.php 53
ERROR - 17-06-2016 12:06:08 --> 404 Page Not Found: Vendor/bootstrap
