<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 22-06-2016 04:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 22-06-2016 11:01:23 --> Severity: Notice --> Undefined property: Get_news::$html D:\Projects\webdep\application\controllers\backend\Get_news.php 16
ERROR - 22-06-2016 11:01:23 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 16
ERROR - 22-06-2016 11:10:27 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:10:27 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:34 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:10:34 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:35 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:10:35 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:36 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:10:36 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:10:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:11:03 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:11:03 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:29:59 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:29:59 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:29:59 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:30:09 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:30:09 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:30:09 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:31:26 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:31:26 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:31:26 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:31:40 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:31:40 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:31:40 --> Severity: Notice --> Undefined index: title D:\Projects\webdep\application\views\backend\news\get_news.php 9
ERROR - 22-06-2016 11:38:37 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:38:37 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:40:59 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:40:59 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:40:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:44:49 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:44:49 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:44:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:45:29 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:45:29 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:45:31 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 11:45:31 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:45:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 11:48:17 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 5
ERROR - 22-06-2016 11:48:17 --> Severity: Error --> Call to a member function find() on integer D:\Projects\webdep\application\views\backend\news\get_news.php 8
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:49:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 11:50:12 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:25:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:16 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:26:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:27:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:32:29 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:36:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:37:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 12:38:35 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\views\backend\news\get_news.php 6
ERROR - 22-06-2016 13:04:01 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\system\libraries\Session\drivers\Session_files_driver.php 168
ERROR - 22-06-2016 13:04:02 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\system\libraries\Session\drivers\Session_files_driver.php 168
ERROR - 22-06-2016 13:04:02 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\system\libraries\Session\drivers\Session_files_driver.php 168
ERROR - 22-06-2016 13:07:34 --> Severity: Notice --> Undefined property: Get_news::$news_model D:\Projects\webdep\application\controllers\backend\Get_news.php 33
ERROR - 22-06-2016 13:07:34 --> Severity: Error --> Call to a member function insert() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 33
ERROR - 22-06-2016 13:08:58 --> Query error: Table 'webdep.th_news' doesn't exist - Invalid query: SHOW COLUMNS FROM `th_news`
ERROR - 22-06-2016 15:50:09 --> 404 Page Not Found: Faviconico/index
ERROR - 22-06-2016 15:50:30 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 24
ERROR - 22-06-2016 15:52:34 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\system\libraries\Session\drivers\Session_files_driver.php 168
ERROR - 22-06-2016 15:54:42 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 15:54:42 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 15:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 15:54:42 --> Severity: Notice --> Undefined variable: descs D:\Projects\webdep\application\views\backend\news\get_news.php 13
ERROR - 22-06-2016 15:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 13
ERROR - 22-06-2016 16:01:17 --> 404 Page Not Found: Faviconico/index
ERROR - 22-06-2016 16:01:23 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 2
ERROR - 22-06-2016 16:01:23 --> Severity: Notice --> Undefined variable: titles D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 16:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 3
ERROR - 22-06-2016 16:01:23 --> Severity: Notice --> Undefined variable: descs D:\Projects\webdep\application\views\backend\news\get_news.php 13
ERROR - 22-06-2016 16:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\Projects\webdep\application\views\backend\news\get_news.php 13
ERROR - 22-06-2016 16:08:16 --> Severity: Error --> Call to a member function load_file() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 39
ERROR - 22-06-2016 16:08:40 --> Severity: Error --> Call to a member function load_file() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 39
ERROR - 22-06-2016 16:08:58 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 22-06-2016 16:09:35 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 22-06-2016 16:09:53 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 22-06-2016 16:10:24 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 41
ERROR - 22-06-2016 16:10:27 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 41
ERROR - 22-06-2016 16:11:49 --> Severity: Error --> Call to undefined method simple_html_dom::file_get_html() D:\Projects\webdep\application\controllers\backend\Get_news.php 39
ERROR - 22-06-2016 16:12:50 --> Severity: Error --> Call to undefined method simple_html_dom::file_get_content() D:\Projects\webdep\application\controllers\backend\Get_news.php 39
ERROR - 22-06-2016 16:12:56 --> Severity: Error --> Call to undefined method simple_html_dom::file_get_contents() D:\Projects\webdep\application\controllers\backend\Get_news.php 39
ERROR - 22-06-2016 16:13:51 --> Severity: Error --> Call to undefined method simple_html_dom::file_get_html() D:\Projects\webdep\application\controllers\backend\Get_news.php 39
ERROR - 22-06-2016 16:16:54 --> Severity: Error --> Call to undefined method simple_html_dom::file_get_html() D:\Projects\webdep\application\controllers\backend\Get_news.php 40
ERROR - 22-06-2016 16:17:11 --> Severity: Error --> Call to a member function find() on null D:\Projects\webdep\application\controllers\backend\Get_news.php 42
ERROR - 22-06-2016 16:26:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:31:32 --> 404 Page Not Found: Faviconico/index
ERROR - 22-06-2016 16:32:41 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:41 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:41 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:41 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:42 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:42 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:42 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:42 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:42 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:43 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:44 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:44 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:44 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:44 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:44 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:45 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:45 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:45 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:46 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:46 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:46 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:46 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:47 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:47 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:47 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:48 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:48 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:48 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:48 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:49 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:49 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:49 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:50 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:50 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:50 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:50 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:50 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:51 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:51 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:51 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:51 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:52 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:52 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:52 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:53 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:53 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:53 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:53 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:54 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:54 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:54 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:55 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:56 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:57 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:57 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:57 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:57 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:57 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:58 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:58 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:58 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:58 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:59 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:59 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:32:59 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:00 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:01 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:01 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:01 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:02 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:02 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:02 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:02 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:02 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:03 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:03 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:03 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:04 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:04 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:04 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:04 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:05 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:05 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:06 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:06 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:06 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:06 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:06 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:07 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:07 --> Severity: Warning --> file_get_contents() expects at least 1 parameter, 0 given D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:33:07 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:15 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:34:15 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:34:15 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:15 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:39 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:39 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:40 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:40 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:40 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:40 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:34:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\Projects\webdep\application\controllers\backend\Get_news.php:44) D:\Projects\webdep\system\core\Common.php 573
ERROR - 22-06-2016 16:34:42 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:35:13 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:35:13 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:35:13 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:13 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:31 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:35:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:35:31 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:31 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 44
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:32 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:33 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:33 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:34 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:34 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 47
ERROR - 22-06-2016 16:35:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\Projects\webdep\system\core\Exceptions.php:272) D:\Projects\webdep\system\core\Common.php 573
ERROR - 22-06-2016 16:35:37 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:38:18 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:18 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:36 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:36 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:37 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:37 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:37 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:37 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:38 --> Severity: Notice --> Undefined offset: 0 D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:38 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\controllers\backend\Get_news.php 48
ERROR - 22-06-2016 16:38:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\Projects\webdep\application\controllers\backend\Get_news.php:38) D:\Projects\webdep\system\core\Common.php 573
ERROR - 22-06-2016 16:38:44 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:40:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\Projects\webdep\application\controllers\backend\Get_news.php:45) D:\Projects\webdep\system\core\Common.php 573
ERROR - 22-06-2016 16:40:14 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Projects\webdep\application\third_party\simple_html_dom.php 1097
ERROR - 22-06-2016 16:47:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\third_party\simple_html_dom.php 711
ERROR - 22-06-2016 16:47:05 --> Severity: Notice --> Trying to get property of non-object D:\Projects\webdep\application\third_party\simple_html_dom.php 528
ERROR - 22-06-2016 16:47:05 --> Severity: Error --> Call to a member function seek() on null D:\Projects\webdep\application\third_party\simple_html_dom.php 530
ERROR - 22-06-2016 16:54:51 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) D:\Projects\webdep\application\controllers\backend\Get_news.php 83
ERROR - 22-06-2016 17:45:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\Projects\webdep\application\controllers\backend\Get_news.php 50
ERROR - 22-06-2016 17:46:16 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:16 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:16 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:16 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:17 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:17 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:18 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:18 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:18 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:18 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:19 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:19 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:19 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:19 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:20 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:20 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:21 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:21 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:21 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:21 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:22 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:22 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:22 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:22 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:23 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:23 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:23 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:23 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:23 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:23 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:24 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:24 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:24 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:24 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:24 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:24 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:25 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:25 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:25 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:25 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:25 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:25 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:25 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:25 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:26 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:26 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:26 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:26 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:27 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:27 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:28 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:28 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:28 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:28 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:29 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:29 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:47 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:47 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:47 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:47 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:48 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:48 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:49 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:49 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:49 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:49 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:50 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:50 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:50 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:50 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:51 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:51 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:52 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:52 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:53 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:53 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:53 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:53 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:54 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:54 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:55 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:55 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:55 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:55 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:56 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:56 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:56 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:56 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:56 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:56 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:57 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:57 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:58 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:58 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:59 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:59 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:46:59 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:46:59 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:00 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:00 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:00 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:00 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:01 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:01 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:02 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:02 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:02 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:02 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:03 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:03 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:04 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:04 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:04 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:04 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:04 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:04 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:05 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:05 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:05 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:05 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:06 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:06 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
ERROR - 22-06-2016 17:47:06 --> Severity: Warning --> Missing argument 1 for simple_html_dom::find(), called in D:\Projects\webdep\application\controllers\backend\Get_news.php on line 49 and defined D:\Projects\webdep\application\third_party\simple_html_dom.php 1127
ERROR - 22-06-2016 17:47:06 --> Severity: Notice --> Undefined variable: selector D:\Projects\webdep\application\third_party\simple_html_dom.php 1129
