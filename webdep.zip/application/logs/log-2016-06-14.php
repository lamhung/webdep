<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 14-06-2016 18:25:35 --> Severity: Error --> Call to undefined function base_url() D:\Projects\webdep\application\views\backend\layout\header.php 6
ERROR - 14-06-2016 18:27:53 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 14-06-2016 18:27:55 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 14-06-2016 18:28:04 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 14-06-2016 18:28:11 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 14-06-2016 18:29:00 --> 404 Page Not Found: Vendor/js
ERROR - 14-06-2016 18:29:02 --> 404 Page Not Found: Vendor/js
ERROR - 14-06-2016 18:29:24 --> 404 Page Not Found: Vendor/js
ERROR - 14-06-2016 18:29:28 --> 404 Page Not Found: Vendor/js
