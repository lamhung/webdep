<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 16-06-2016 08:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 16-06-2016 09:51:50 --> Could not find the language line "user_group_1"
ERROR - 16-06-2016 11:13:35 --> Severity: error --> Exception: D:\Projects\webdep\application\core\MY_Model.php exists, but doesn't declare class MY_Model D:\Projects\webdep\system\core\Loader.php 318
ERROR - 16-06-2016 11:13:59 --> Severity: error --> Exception: D:\Projects\webdep\application\core\MY_Model.php exists, but doesn't declare class MY_Model D:\Projects\webdep\system\core\Loader.php 318
ERROR - 16-06-2016 11:15:02 --> Severity: Error --> Call to undefined method User_model::initialize() D:\Projects\webdep\application\core\MY_Model.php 30
ERROR - 16-06-2016 11:15:14 --> Severity: Error --> Call to undefined function set_value() D:\Projects\webdep\application\views\backend\user\_form.php 7
ERROR - 16-06-2016 11:15:37 --> Severity: Error --> Call to undefined function set_value() D:\Projects\webdep\application\views\backend\user\_form.php 7
ERROR - 16-06-2016 11:15:37 --> Severity: Error --> Call to undefined function set_value() D:\Projects\webdep\application\views\backend\user\_form.php 7
ERROR - 16-06-2016 11:16:08 --> Severity: Error --> Call to undefined function set_value() D:\Projects\webdep\application\views\backend\user\_form.php 7
ERROR - 16-06-2016 11:22:04 --> Severity: Notice --> Undefined index: password D:\Projects\webdep\application\views\backend\user\_form.php 19
ERROR - 16-06-2016 11:29:20 --> 404 Page Not Found: Assets/backend
ERROR - 16-06-2016 11:29:24 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 16-06-2016 11:30:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 16-06-2016 11:31:41 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 16-06-2016 11:31:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 16-06-2016 12:41:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 16-06-2016 15:54:50 --> Query error: Table 'webdep.th_user' doesn't exist - Invalid query: SHOW COLUMNS FROM `th_user`
ERROR - 16-06-2016 15:55:01 --> Query error: Table 'webdep.th_user' doesn't exist - Invalid query: SHOW COLUMNS FROM `th_user`
ERROR - 16-06-2016 17:26:34 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 16-06-2016 17:40:23 --> Severity: Notice --> Undefined property: User::$db D:\Projects\webdep\system\core\Model.php 77
ERROR - 16-06-2016 17:40:23 --> Severity: Error --> Call to a member function insert() on null D:\Projects\webdep\application\core\MY_Model.php 70
ERROR - 16-06-2016 17:42:20 --> Severity: Notice --> Undefined property: User::$db D:\Projects\webdep\system\core\Model.php 77
ERROR - 16-06-2016 17:42:20 --> Severity: Error --> Call to a member function insert() on null D:\Projects\webdep\application\core\MY_Model.php 70
ERROR - 16-06-2016 17:43:34 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::fields_data() D:\Projects\webdep\application\core\MY_Model.php 44
ERROR - 16-06-2016 17:43:53 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::fields_data() D:\Projects\webdep\application\core\MY_Model.php 44
ERROR - 16-06-2016 17:43:53 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::fields_data() D:\Projects\webdep\application\core\MY_Model.php 44
ERROR - 16-06-2016 17:45:00 --> Severity: Notice --> Undefined property: User::$model D:\Projects\webdep\application\controllers\backend\User.php 30
ERROR - 16-06-2016 17:45:00 --> Severity: Error --> Call to a member function insert_id() on null D:\Projects\webdep\application\controllers\backend\User.php 30
ERROR - 16-06-2016 17:46:22 --> 404 Page Not Found: Acp/user
