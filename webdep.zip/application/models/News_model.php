<?php
class News_model extends MY_Model 
{
    public function __construct()
    {
        parent::__construct('news');
    }
}